from django.contrib import admin
from .models import Event, VolunteerHours


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ("title", "city", "is_public", "created_by", "created_at")
    list_filter = ("is_public", "city")
    search_fields = ("title", "description")


@admin.register(VolunteerHours)
class VolunteerHoursAdmin(admin.ModelAdmin):
    list_display = ("volunteer", "event", "hours")
    list_filter = ("event",)
    search_fields = ("volunteer__username", "volunteer__email", "event__title")